package com.springboot.cloud.gateway.admin.config;

import com.springboot.cloud.common.web.handler.PoMetaObjectHandler;
import org.springframework.stereotype.Component;

@Component
public class MyMetaObjectHandler extends PoMetaObjectHandler {

}